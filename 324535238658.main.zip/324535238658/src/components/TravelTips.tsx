import { motion } from 'framer-motion';
import type { TravelTip } from '@/lib/travelData';

interface TravelTipsProps {
  tips: TravelTip[];
}

const TravelTips: React.FC<TravelTipsProps> = ({ tips }) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      className="grid grid-cols-1 md:grid-cols-2 gap-4"
    >
      {tips.map((tip) => (
        <motion.div 
          key={tip.id}
          variants={itemVariants}
          className="flex items-start p-4 rounded-lg bg-blue-50 dark:bg-blue-900/20"
        >
          <div className="bg-blue-500 text-white p-3 rounded-full mr-4">
            <i className={`fa-solid ${tip.icon}`}></i>
          </div>
          <div>
            <h4 className="font-semibold text-lg mb-1">{tip.title}</h4>
            <p className="text-slate-600 dark:text-slate-300">{tip.content}</p>
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
};

export default TravelTips;