import { Link } from 'react-router-dom';
import { useTheme } from '@/hooks/useTheme';

export const Navigation = () => {
  const { theme } = useTheme();
  
  const menuItems = [
    { title: '行程概览', path: '/', icon: 'fa-map-location-dot' },
    { title: '每日行程', path: '/itinerary', icon: 'fa-route' },
    { title: '推荐景点', path: '/attractions', icon: 'fa-landmark' },
    { title: '美食推荐', path: '/food', icon: 'fa-utensils' },
    { title: '旅行贴士', path: '/tips', icon: 'fa-lightbulb' },
    { title: '后勤保障', path: '/logistics', icon: 'fa-suitcase' },
  ];
  
  return (
    <nav className={`sticky top-0 z-40 ${theme === 'dark' ? 'bg-slate-800/90' : 'bg-white/90'} backdrop-blur-md shadow-md py-4`}>
      <div className="max-w-7xl mx-auto px-4">
        <ul className="flex flex-wrap justify-center gap-2 md:gap-6">
          {menuItems.map((item, index) => (
            <li key={index}>
              <Link 
                to={item.path}
                className={`flex items-center px-3 py-2 rounded-full transition-all ${
                  theme === 'dark'
                    ? 'hover:bg-slate-700 text-white'
                    : 'hover:bg-slate-100 text-slate-700'
                }`}
              >
                <i className={`fa-solid ${item.icon} mr-1`}></i>
                <span>{item.title}</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
};