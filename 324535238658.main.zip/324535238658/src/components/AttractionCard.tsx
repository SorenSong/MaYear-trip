import { motion } from 'framer-motion';
import type { Attraction } from '@/lib/travelData';

interface AttractionCardProps {
  attraction: Attraction;
  theme: 'light' | 'dark';
}

const AttractionCard: React.FC<AttractionCardProps> = ({ attraction, theme }) => {
  const cardVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
    hover: { y: -5, transition: { duration: 0.2 } }
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      whileInView="visible"
      whileHover="hover"
      viewport={{ once: true }}
      className={`rounded-xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'}`}
    >
      {/* Image */}
      <div className="h-48 overflow-hidden">
        <img 
          src={attraction.image} 
          alt={attraction.name} 
          className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
        />
      </div>

      {/* Content */}
      <div className="p-5">
        <h3 className="text-xl font-bold mb-2">{attraction.name}</h3>
        <p className={`mb-4 line-clamp-3 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>
          {attraction.description}
        </p>

        {/* Details */}
        <div className="space-y-2">
          <div className="flex items-start">
            <i className="fa-solid fa-location-dot text-blue-500 mt-1 mr-2 flex-shrink-0"></i>
            <span className="text-sm">{attraction.location}</span>
          </div>
          <div className="flex items-start">
            <i className="fa-solid fa-clock text-blue-500 mt-1 mr-2 flex-shrink-0"></i>
            <span className="text-sm">开放时间: {attraction.openingHours}</span>
          </div>
          <div className="flex items-start">
            <i className="fa-solid fa-ticket text-blue-500 mt-1 mr-2 flex-shrink-0"></i>
            <span className="text-sm">门票: {attraction.ticketPrice}</span>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default AttractionCard;