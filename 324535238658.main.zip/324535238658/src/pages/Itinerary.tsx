import { useState } from 'react';
import { motion } from 'framer-motion';
import ItineraryDay from '@/components/ItineraryDay';
import { itineraryData } from '@/lib/travelData';
import { useTheme } from '@/hooks/useTheme';

export default function Itinerary() {
  const [activeDay, setActiveDay] = useState(1);
  const { theme } = useTheme();

  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900'}`}>
      {/* Hero Section */}
      <section className="relative h-[30vh] overflow-hidden">
        <img 
          src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Zhanjiang%20travel%20itinerary%20map%20with%20route%20marked&sign=bfd716a5421753fa082728dced939249"
          alt="行程路线" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
          <div className="p-8 max-w-7xl mx-auto w-full">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={fadeInUp}
            >
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">每日行程</h1>
              <p className="text-lg text-white/90">详细的湛江4天3晚行程安排</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        <motion.section 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeInUp}
        >
          {/* Day Selection Tabs */}
          <div className="flex flex-wrap gap-2 mb-8">
            {itineraryData.map((day) => (
              <button
                key={day.day}
                onClick={() => setActiveDay(day.day)}
                className={`px-4 py-2 rounded-full font-medium transition-all ${
                  activeDay === day.day
                    ? 'bg-blue-500 text-white shadow-md'
                    : theme === 'dark'
                    ? 'bg-slate-800 hover:bg-slate-700'
                    : 'bg-white hover:bg-slate-100 shadow-sm'
                }`}
              >
                第{day.day}天
              </button>
            ))}
          </div>

          {/* Selected Day Itinerary */}
          {itineraryData
            .filter((day) => day.day === activeDay)
            .map((day) => (
              <ItineraryDay key={day.day} day={day} theme={theme} />
            ))}
        </motion.section>
      </main>

      {/* Footer */}
      <footer className={`py-8 ${theme === 'dark' ? 'bg-slate-800 text-white/80' : 'bg-slate-100 text-slate-600'}`}>
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p>湛江4天3晚旅行计划 | 祝您旅途愉快！</p>
          <div className="flex justify-center space-x-4 mt-4">
            <a href="#" className="hover:text-blue-500 transition-colors">
              <i className="fa-solid fa-share-alt"></i> 分享
            </a>
            <a href="#" className="hover:text-blue-500 transition-colors">
              <i className="fa-solid fa-print"></i> 打印
            </a>
            <a href="#" className="hover:text-blue-500 transition-colors">
              <i className="fa-solid fa-download"></i> 下载
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}