import { motion } from 'framer-motion';
import TravelTips from '@/components/TravelTips';
import { tips } from '@/lib/travelData';
import { useTheme } from '@/hooks/useTheme';

export default function Tips() {
  const { theme } = useTheme();

  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900'}`}>
      {/* Hero Section */}
      <section className="relative h-[30vh] overflow-hidden">
        <img 
          src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Travel%20tips%20and%20advice%20concept%20with%20lightbulb%20and%20compass&sign=6eb66d85d99191fdf23b7604acdd925a"
          alt="旅行贴士" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
          <div className="p-8 max-w-7xl mx-auto w-full">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={fadeInUp}
            >
              <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">旅行贴士</h1>
              <p className="text-lg text-white/90">湛江旅行的实用建议和注意事项</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        <motion.section 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeInUp}
        >
          <div className={`p-6 rounded-xl shadow-lg ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'}`}>
            <TravelTips tips={tips} />
          </div>
        </motion.section>
      </main>

      {/* Footer */}
      <footer className={`py-8 ${theme === 'dark' ? 'bg-slate-800 text-white/80' : 'bg-slate-100 text-slate-600'}`}>
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p>湛江4天3晚旅行计划 | 祝您旅途愉快！</p>
          <div className="flex justify-center space-x-4 mt-4">
            <a href="#" className="hover:text-blue-500 transition-colors">
              <i className="fa-solid fa-share-alt"></i> 分享
            </a>
            <a href="#" className="hover:text-blue-500 transition-colors">
              <i className="fa-solid fa-print"></i> 打印
            </a>
            <a href="#" className="hover:text-blue-500 transition-colors">
              <i className="fa-solid fa-download"></i> 下载
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}