import { motion } from 'framer-motion';
import type { ItineraryDay as ItineraryDayType } from '@/lib/travelData';

interface ItineraryDayProps {
  day: ItineraryDayType;
  theme: 'light' | 'dark';
}

const ItineraryDay: React.FC<ItineraryDayProps> = ({ day, theme }) => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className={`rounded-xl shadow-lg overflow-hidden ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'}`}
    >
      {/* Day Header */}
      <div className="bg-blue-500 text-white p-6">
        <h3 className="text-2xl font-bold">第{day.day}天: {day.title}</h3>
        <p className="mt-2 opacity-90">{day.description}</p>
      </div>

      {/* Activities */}
      <div className="p-6">
        <h4 className="text-lg font-semibold mb-4 flex items-center">
          <i className="fa-solid fa-list-check mr-2 text-blue-500"></i>
          活动安排
        </h4>
        <div className="space-y-6">
          {day.activities.map((activity, index) => (
            <motion.div 
              key={index}
              variants={itemVariants}
              className={`p-4 rounded-lg border-l-4 border-blue-500 ${theme === 'dark' ? 'bg-slate-700' : 'bg-slate-50'}`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center mb-2">
                <span className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100 px-3 py-1 rounded-full text-sm font-medium inline-block mb-2 sm:mb-0 sm:mr-3">
                  {activity.time}
                </span>
                <h5 className="text-xl font-medium">{activity.title}</h5>
              </div>
              <p className={`${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>
                {activity.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default ItineraryDay;