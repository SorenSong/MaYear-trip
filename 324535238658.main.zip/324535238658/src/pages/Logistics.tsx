import { useState } from "react";
import { motion } from "framer-motion";
import { budgetData, checklistData, type ChecklistItem } from "@/lib/travelData";
import { useTheme } from "@/hooks/useTheme";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";

export default function Logistics() {
    const {
        theme
    } = useTheme();

    const [checklist, setChecklist] = useState<ChecklistItem[]>(checklistData);

    const fadeInUp = {
        hidden: {
            opacity: 0,
            y: 20
        },

        visible: {
            opacity: 1,
            y: 0,

            transition: {
                duration: 0.6
            }
        }
    };

    const totalBudget = budgetData.reduce((sum, item) => sum + item.cost, 0);

    const pieData = budgetData.reduce((acc: any[], item) => {
        const existingCategory = acc.find(cat => cat.name === item.category);

        if (existingCategory) {
            existingCategory.value += item.cost;
        } else {
            acc.push({
                name: item.category,
                value: item.cost
            });
        }

        return acc;
    }, []);

    const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8", "#82ca9d"];

    const toggleChecklistItem = (id: number) => {
        setChecklist(checklist.map(item => item.id === id ? {
            ...item,
            checked: !item.checked
        } : item));
    };

    const groupedChecklist = checklist.reduce((acc: Record<string, ChecklistItem[]>, item) => {
        if (!acc[item.category]) {
            acc[item.category] = [];
        }

        acc[item.category].push(item);
        return acc;
    }, {});

    return (
        <div
            className={`min-h-screen ${theme === "dark" ? "bg-slate-900 text-white" : "bg-slate-50 text-slate-900"}`}>
            {}
            <section className="relative h-[30vh] overflow-hidden">
                <img
                    src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Travel%20budget%20and%20checklist%20concept%20with%20documents%20and%20calculator&sign=9fc3df2a2d8c121df5e788305604d2ed"
                    alt="后勤保障"
                    className="absolute inset-0 w-full h-full object-cover" />
                <div
                    className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                    <div className="p-8 max-w-7xl mx-auto w-full">
                        <motion.div initial="hidden" animate="visible" variants={fadeInUp}>
                            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">后勤保障</h1>
                            <p className="text-lg text-white/90">旅行预算和必备物品清单</p>
                        </motion.div>
                    </div>
                </div>
            </section>
            {}
            <main className="max-w-7xl mx-auto px-4 py-12">
                {}
                <motion.section
                    initial="hidden"
                    whileInView="visible"
                    viewport={{
                        once: true
                    }}
                    variants={fadeInUp}
                    className="mb-16">
                    <h2 className="text-3xl font-bold mb-6 flex items-center">
                        <i className="fa-solid fa-credit-card mr-2 text-blue-500"></i>旅行预算
                                                          </h2>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        {}
                        <div
                            className={`p-6 rounded-xl shadow-lg ${theme === "dark" ? "bg-slate-800" : "bg-white"}`}>
                            <h3 className="text-xl font-semibold mb-4">预算明细</h3>
                            <div className="space-y-3">
                                {budgetData.map(item => <div
                                    key={item.id}
                                    className="flex justify-between items-center pb-2 border-b border-slate-200 dark:border-slate-700">
                                    <div>
                                        <span className="font-medium">{item.item}</span>
                                        <span className="ml-2 text-sm text-slate-500 dark:text-slate-400">({item.category})</span>
                                    </div>
                                    <span className="font-semibold">¥0{item.cost.toFixed(2)}</span>
                                </div>)}
                                <div className="flex justify-between items-center pt-2 font-bold text-xl">
                                    <span>总计</span>
                                    <span className="text-blue-500">¥0{totalBudget.toFixed(2)}</span>
                                </div>
                            </div>
                        </div>
                        {}
                        <div
                            className={`p-6 rounded-xl shadow-lg ${theme === "dark" ? "bg-slate-800" : "bg-white"} flex flex-col items-center justify-center`}>
                            <h3 className="text-xl font-semibold mb-4 text-center">预算分布</h3>
                            <div className="w-full h-64">
                                <ResponsiveContainer width="100%" height="100%">
                                    <PieChart>
                                        <Pie
                                            data={pieData}
                                            cx="50%"
                                            cy="50%"
                                            labelLine={false}
                                            label={(
                                                {
                                                    name,
                                                    percent
                                                }
                                            ) => `${name} ${(percent * 100).toFixed(0)}%`}
                                            outerRadius={80}
                                            fill="#8884d8"
                                            dataKey="value">
                                            {pieData.map(
                                                (entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                            )}
                                        </Pie>
                                        <Tooltip formatter={(value: number) => `¥${value}`} />
                                        <Legend />
                                    </PieChart>
                                </ResponsiveContainer>
                            </div>
                        </div>
                    </div>
                </motion.section>
                {}
                <motion.section
                    initial="hidden"
                    whileInView="visible"
                    viewport={{
                        once: true
                    }}
                    variants={fadeInUp}>
                    <h2 className="text-3xl font-bold mb-6 flex items-center">
                        <i className="fa-solid fa-list-check mr-2 text-blue-500"></i>旅行清单
                                                          </h2>
                    <div
                        className={`p-6 rounded-xl shadow-lg ${theme === "dark" ? "bg-slate-800" : "bg-white"}`}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {Object.entries(groupedChecklist).map(([category, items]) => <div key={category}>
                                <h3 className="text-lg font-semibold mb-3 text-blue-500">{category}</h3>
                                <div className="space-y-2">
                                    {items.map(item => <div
                                        key={item.id}
                                        className={`flex items-center p-3 rounded-lg transition-all ${theme === "dark" ? "bg-slate-700 hover:bg-slate-600" : "bg-slate-50 hover:bg-slate-100"}`}
                                        onClick={() => toggleChecklistItem(item.id)}>
                                        <input
                                            type="checkbox"
                                            checked={item.checked}
                                            onChange={() => toggleChecklistItem(item.id)}
                                            className="mr-3 h-5 w-5 rounded text-blue-500 focus:ring-blue-500" />
                                        <span className={item.checked ? "line-through opacity-60" : ""}>
                                            {item.item}
                                        </span>
                                    </div>)}
                                </div>
                            </div>)}
                        </div>
                        {}
                        <div
                            className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center">
                            <span>已完成: <strong className="text-blue-500">{checklist.filter(item => item.checked).length}/{checklist.length}</strong>
                            </span>
                            <button
                                className="px-4 py-2 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-colors"
                                onClick={() => setChecklist(checklist.map(item => ({
                                    ...item,
                                    checked: false
                                })))}>重置清单
                                                                              </button>
                        </div>
                    </div>
                </motion.section>
            </main>
            {}
            <footer
                className={`py-8 ${theme === "dark" ? "bg-slate-800 text-white/80" : "bg-slate-100 text-slate-600"}`}>
                <div className="max-w-7xl mx-auto px-4 text-center">
                    <p>湛江4天3晚旅行计划 | 祝您旅途愉快！</p>
                    <div className="flex justify-center space-x-4 mt-4">
                        <a href="#" className="hover:text-blue-500 transition-colors">
                            <i className="fa-solid fa-share-alt"></i>分享
                                                                    </a>
                        <a href="#" className="hover:text-blue-500 transition-colors">
                            <i className="fa-solid fa-print"></i>打印
                                                                    </a>
                        <a href="#" className="hover:text-blue-500 transition-colors">
                            <i className="fa-solid fa-download"></i>下载
                                                                    </a>
                    </div>
                </div>
            </footer>
        </div>
    );
}