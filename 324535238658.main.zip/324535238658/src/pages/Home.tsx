import { Redirect } from 'react-router-dom';

// 重定向到概览页面
export default function Home() {
  return <Redirect to="/" />;
}