// 定义行程数据类型
export interface ItineraryDay {
  day: number;
  title: string;
  description: string;
  activities: Array<{
    time: string;
    title: string;
    description: string;
  }>;
}

export interface Attraction {
  id: number;
  name: string;
  description: string;
  image: string;
  location: string;
  openingHours: string;
  ticketPrice: string;
}

export interface Food {
  id: number;
  name: string;
  description: string;
  image: string;
  location: string;
  recommended: boolean;
}

export interface TravelTip {
  id: number;
  title: string;
  content: string;
  icon: string;
}

// 行程数据
export const itineraryData: ItineraryDay[] = [
  {
    day: 1,
    title: "抵达湛江，市区游览",
    description: "抵达湛江后，游览市区主要景点，了解湛江城市风貌",
    activities: [
      {
        time: "上午",
        title: "抵达湛江",
        description: "乘坐飞机或火车抵达湛江，入住酒店后稍作休息"
      },
      {
        time: "下午",
        title: "金沙湾观海长廊",
        description: "游览湛江市区著名的海滨景点，欣赏海湾风光"
      },
      {
        time: "傍晚",
        title: "广州湾法国公使署旧址",
        description: "参观历史建筑，了解湛江的历史文化"
      },
      {
        time: "晚上",
        title: "海滨公园夜市",
        description: "品尝当地特色小吃，体验湛江夜市文化"
      }
    ]
  },
  {
    day: 2,
    title: "东海岛一日游",
    description: "前往中国第五大岛——东海岛，享受阳光沙滩",
    activities: [
      {
        time: "上午",
        title: "东海岛",
        description: "乘车前往东海岛，游览龙海天沙滩"
      },
      {
        time: "中午",
        title: "海鲜午餐",
        description: "在岛上品尝新鲜海鲜"
      },
      {
        time: "下午",
        title: "沙滩活动",
        description: "可参与水上活动或在沙滩上放松休息"
      },
      {
        time: "傍晚",
        title: "返回市区",
        description: "乘车返回湛江市区，晚餐后休息"
      }
    ]
  },
  {
    day: 3,
    title: "雷州半岛文化之旅",
    description: "探索雷州半岛的历史文化和自然景观",
    activities: [
      {
        time: "上午",
        title: "雷祖祠",
        description: "参观纪念唐代雷州首任刺史陈文玉的祠堂"
      },
      {
        time: "中午",
        title: "雷州古城午餐",
        description: "品尝雷州特色美食"
      },
      {
        time: "下午",
        title: "湖光岩",
        description: "游览世界地质公园——湖光岩，参观玛珥湖"
      },
      {
        time: "晚上",
        title: "海滨晚餐",
        description: "在海滨餐厅享用海鲜晚餐，欣赏夜景"
      }
    ]
  },
  {
    day: 4,
    title: "湛江湾与返程",
    description: "最后一天游览湛江湾，购买特产，结束愉快的旅程",
    activities: [
      {
        time: "上午",
        title: "湛江港湾游",
        description: "乘坐游船游览湛江湾，欣赏港湾风光"
      },
      {
        time: "中午",
        title: "特产购买",
        description: "前往当地市场购买湛江特产"
      },
      {
        time: "下午",
        title: "返程",
        description: "根据航班或车次时间，前往机场或火车站返程"
      }
    ]
  }
];

// 景点数据
export const attractions: Attraction[] = [
  {
    id: 1,
    name: "金沙湾观海长廊",
    description: "湛江市区最著名的海滨景点，拥有绵延数公里的金色沙滩和椰林，是休闲散步的好去处。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Zhanjiang%20Golden%20Sandy%20Beach%20with%20blue%20sea%20and%20coconut%20trees&sign=7dd68bc921267410d9d5a366c4ebc384",
    location: "湛江市赤坎区金沙湾",
    openingHours: "全天开放",
    ticketPrice: "免费"
  },
  {
    id: 2,
    name: "湖光岩",
    description: "世界地质公园，拥有中国唯一的玛珥湖，湖水清澈见底，周围环境优美，是天然氧吧。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Lake%20Guangyan%20scenic%20area%20with%20clear%20water%20and%20surrounding%20mountains&sign=2799256edfa411d7a273554882057755",
    location: "湛江市麻章区湖光镇",
    openingHours: "07:30-18:00",
    ticketPrice: "50元/人"
  },
  {
    id: 3,
    name: "东海岛",
    description: "中国第五大岛，拥有中国第一长滩——龙海天沙滩，沙质细腻，海水清澈。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Donghai%20Island%20long%20beach%20with%20white%20sand%20and%20blue%20ocean&sign=70981584608faa50eef6f7cce27a5003",
    location: "湛江市东海岛经济开发试验区",
    openingHours: "全天开放",
    ticketPrice: "免费（部分景点收费）"
  },
  {
    id: 4,
    name: "雷祖祠",
    description: "为纪念唐代雷州首任刺史陈文玉而建，是雷州半岛重要的文化遗产，具有浓厚的历史文化底蕴。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Leizu%20Temple%20ancient%20architecture%20with%20traditional%20Chinese%20style&sign=c6b45ccfcdb99c8024b2818c014efc35",
    location: "湛江市雷州市雷州大道",
    openingHours: "08:30-17:30",
    ticketPrice: "15元/人"
  },
  {
    id: 5,
    name: "广州湾法国公使署旧址",
    description: "建于1903年，是湛江百年历史的见证，建筑风格独特，现为湛江博物馆。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Former%20French%20Consulate%20in%20Guangzhouwan%20with%20colonial%20architecture&sign=010ff3ae615ca2d5f234348786f8678e",
    location: "湛江市霞山区海滨大道",
    openingHours: "09:00-17:00（周一闭馆）",
    ticketPrice: "免费"
  },
  {
    id: 6,
    name: "南亚热带植物园",
    description: "集科研、科普、观光于一体的植物园，拥有丰富的热带植物资源。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Tropical%20Botanical%20Garden%20with%20various%20plants%20and%20greenhouse&sign=88ac1a539223836b138df6b1db2fba42",
    location: "湛江市麻章区湖光镇",
    openingHours: "08:00-17:30",
    ticketPrice: "25元/人"
  }
];

// 美食数据
export const foods: Food[] = [
  {
    id: 1,
    name: "湛江白切鸡",
    description: "湛江最著名的特色菜，皮黄肉白，肉质嫩滑，蘸上姜葱酱料，味道鲜美。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Zhanjiang%20white%20cut%20chicken%20traditional%20Chinese%20food&sign=2c1333592b0d09ddaae9b596516c6cc1",
    location: "湛江市内各大餐馆均有提供",
    recommended: true
  },
  {
    id: 2,
    name: "炭烧生蚝",
    description: "湛江的招牌美食，新鲜生蚝用炭火烧烤，配以蒜蓉和调味料，鲜美多汁。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Grilled%20oysters%20with%20garlic%20and%20herbs&sign=5619100fa8ab00a8cd2f290ea0d5471e",
    location: "海滨公园夜市、赤坎老街",
    recommended: true
  },
  {
    id: 3,
    name: "雷州牛肉",
    description: "雷州的特色美食，牛肉鲜嫩，汤头浓郁，配上特制酱料，风味独特。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Leizhou%20beef%20noodle%20soup%20with%20fresh%20beef&sign=dee6e062d6a34194f77093c4c92af76a",
    location: "雷州市区各牛肉店",
    recommended: true
  },
  {
    id: 4,
    name: "海蜇皮",
    description: "湛江的特色海产品，爽脆可口，常作为开胃小菜或凉拌食用。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Chinese%20style%20jellyfish%20salad%20appetizer&sign=77135d4143ccaf9d6b918baa17992769",
    location: "各大海鲜餐厅",
    recommended: false
  },
  {
    id: 5,
    name: "沙虫汤",
    description: "湛江的特色汤品，沙虫营养丰富，汤味鲜甜，是当地的滋补佳品。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Soup%20with%20sand%20worm%20delicacy%20in%20Zhanjiang&sign=d8459e12676e279c468105ad39ad4638",
    location: "海滨海鲜餐厅",
    recommended: true
  },
  {
    id: 6,
    name: "木叶夹",
    description: "湛江传统小吃，用糯米粉包裹馅料，再用树叶包裹蒸熟，口感软糯，味道香甜。",
    image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_4_3&prompt=Traditional%20Zhanjiang%20snack%20made%20of%20glutinous%20rice%20and%20leaves&sign=499ff8fecaf82d21479826d70decbc78",
    location: "赤坎老街、各大市场",
    recommended: false
  }
];

// 旅行贴士数据
export const tips: TravelTip[] = [
  {
    id: 1,
    title: "最佳旅游时间",
    content: "湛江的最佳旅游时间是春秋两季（11月至次年3月），此时气候宜人，温度适中，适合户外活动。",
    icon: "fa-calendar-alt"
  },
  {
    id: 2,
    title: "交通方式",
    content: "湛江有机场和火车站，可乘坐飞机或火车抵达。市内交通以公交车和出租车为主，也可租车自驾。",
    icon: "fa-plane-departure"
  },
  {
    id: 3,
    title: "住宿建议",
    content: "建议选择住在湛江市区或金沙湾附近，交通便利，周边设施完善，距离主要景点较近。",
    icon: "fa-hotel"
  },
  {
    id: 4,
    title: "饮食注意事项",
    content: "湛江海鲜丰富，但要注意选择新鲜的海鲜，避免食用未熟透的海产品。同时，当地饮食偏清淡，如有特殊口味需求，可提前告知餐厅。",
    icon: "fa-utensils"
  },
  {
    id: 5,
    title: "购物推荐",
    content: "湛江的特产有海鲜干货、雷州蜜枣、廉江红橙等，可以在当地市场或超市购买。",
    icon: "fa-shopping-bag"
  },
  {
    id: 6,
    title: "防晒措施",
    content: "湛江日照强烈，特别是在海边活动时，要做好防晒措施，涂抹防晒霜，戴帽子和太阳镜。",
    icon: "fa-umbrella-beach"
  }
];

// 预算数据
export interface BudgetItem {
  id: number;
  category: string;
  item: string;
  cost: number;
}

export const budgetData: BudgetItem[] = [
  { id: 1, category: '交通', item: '往返机票', cost: 800 },
  { id: 2, category: '交通', item: '市内交通', cost: 200 },
  { id: 3, category: '住宿', item: '3晚酒店', cost: 600 },
  { id: 4, category: '餐饮', item: '每日三餐', cost: 500 },
  { id: 5, category: '景点', item: '门票费用', cost: 200 },
  { id: 6, category: '购物', item: '特产购买', cost: 300 },
  { id: 7, category: '其他', item: '应急费用', cost: 100 },
];

// 旅行清单数据
export interface ChecklistItem {
  id: number;
  category: string;
  item: string;
  checked: boolean;
}

export const checklistData: ChecklistItem[] = [
  { id: 1, category: '证件', item: '身份证', checked: false },
  { id: 2, category: '证件', item: '银行卡/现金', checked: false },
  { id: 3, category: '证件', item: '行程单/酒店预订单', checked: false },
  { id: 4, category: '衣物', item: '换洗衣物', checked: false },
  { id: 5, category: '衣物', item: '泳衣/沙滩鞋', checked: false },
  { id: 6, category: '衣物', item: '防晒帽/墨镜', checked: false },
  { id: 7, category: '个人用品', item: '牙刷/牙膏', checked: false },
  { id: 8, category: '个人用品', item: '护肤品/化妆品', checked: false },
  { id: 9, category: '个人用品', item: '防晒霜', checked: false },
  { id: 10, category: '电子设备', item: '手机/充电器', checked: false },
  { id: 11, category: '电子设备', item: '相机/存储卡', checked: false },
  { id: 12, category: '其他', item: '雨伞', checked: false },
  { id: 13, category: '其他', item: '常用药品', checked: false },
  { id: 14, category: '其他', item: '水杯', checked: false },
];