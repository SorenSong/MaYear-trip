import { motion } from 'framer-motion';
import type { Food } from '@/lib/travelData';

interface FoodRecommendationProps {
  food: Food;
  theme: 'light' | 'dark';
}

const FoodRecommendation: React.FC<FoodRecommendationProps> = ({ food, theme }) => {
  const cardVariants = {
    hidden: { opacity: 0, x: -20 },
    visible: { opacity: 1, x: 0 },
    hover: { scale: 1.02, transition: { duration: 0.2 } }
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      whileInView="visible"
      whileHover="hover"
      viewport={{ once: true }}
      className={`flex rounded-xl overflow-hidden shadow-lg ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'}`}
    >
      {/* Image */}
      <div className="w-1/3">
        <img 
          src={food.image} 
          alt={food.name} 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="w-2/3 p-5">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xl font-bold">{food.name}</h3>
          {food.recommended && (
            <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
              <i className="fa-solid fa-fire"></i> 必尝
            </span>
          )}
        </div>
        <p className={`mb-4 ${theme === 'dark' ? 'text-slate-300' : 'text-slate-600'}`}>
          {food.description}
        </p>
        <div className="flex items-start">
          <i className="fa-solid fa-location-dot text-blue-500 mt-1 mr-2"></i>
          <span className="text-sm">{food.location}</span>
        </div>
      </div>
    </motion.div>
  );
};

export default FoodRecommendation;