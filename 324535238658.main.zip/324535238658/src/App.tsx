import { Routes, Route } from "react-router-dom";
import Overview from "@/pages/Overview";
import Itinerary from "@/pages/Itinerary";
import Attractions from "@/pages/Attractions";
import Food from "@/pages/Food";
import Tips from "@/pages/Tips";
import Logistics from "@/pages/Logistics";
import { Navigation } from "@/components/Navigation";
import { useState } from "react";
import { AuthContext } from '@/contexts/authContext';
import { useTheme } from '@/hooks/useTheme';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const { theme, toggleTheme } = useTheme();

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, setIsAuthenticated, logout }}
    >
      {/* Theme Toggle Button */}
      <button 
        onClick={toggleTheme}
        className="fixed top-4 right-4 p-3 rounded-full bg-white/80 dark:bg-slate-800/80 backdrop-blur-sm shadow-lg z-50"
        aria-label="Toggle theme"
      >
        {theme === 'dark' ? (
          <i className="fa-solid fa-sun text-yellow-500"></i>
        ) : (
          <i className="fa-solid fa-moon text-slate-700"></i>
        )}
      </button>
      
      <Navigation />
      
      <Routes>
        <Route path="/" element={<Overview />} />
        <Route path="/itinerary" element={<Itinerary />} />
        <Route path="/attractions" element={<Attractions />} />
        <Route path="/food" element={<Food />} />
        <Route path="/tips" element={<Tips />} />
        <Route path="/logistics" element={<Logistics />} />
      </Routes>
    </AuthContext.Provider>
  );
}
