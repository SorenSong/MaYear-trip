import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';

export default function Overview() {
  const { theme } = useTheme();
  
  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };
  
  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-900'}`}>
      {/* Hero Section */}
      <section className="relative h-[50vh] overflow-hidden">
        <img 
          src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Zhanjiang%20coastal%20city%20view%20with%20blue%20sea%20and%20clear%20sky%2C%20beautiful%20scenery&sign=c0e4be3e349bf0fad57bdd94166ece4e"
          alt="湛江风景" 
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
          <div className="p-8 max-w-7xl mx-auto w-full">
            <motion.div 
              initial="hidden"
              animate="visible"
              variants={fadeInUp}
            >
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-2">湛江4天3晚旅行计划</h1>
              <p className="text-xl text-white/90 max-w-2xl">探索广东最南端的海滨城市，感受独特的雷州文化和美食天堂</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-12">
        {/* Overview Section */}
        <motion.section 
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeInUp}
        >
          <h2 className="text-3xl font-bold mb-6 flex items-center">
            <i className="fa-solid fa-map-location-dot mr-2 text-blue-500"></i>
            行程概览
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className={`p-6 rounded-xl shadow-lg ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'}`}>
              <h3 className="text-xl font-semibold mb-3 text-blue-500">行程亮点</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>畅游中国大陆最南端的雷州半岛</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>探索湛江湾、东海岛等绝美海景</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>品尝新鲜海鲜和雷州特色美食</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-2"></i>
                  <span>体验雷州文化和历史古迹</span>
                </li>
              </ul>
            </div>
            <div className={`p-6 rounded-xl shadow-lg ${theme === 'dark' ? 'bg-slate-800' : 'bg-white'}`}>
              <h3 className="text-xl font-semibold mb-3 text-blue-500">旅行信息</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <i className="fa-solid fa-calendar-days text-blue-500 mt-1 mr-2"></i>
                  <span>建议出行时间：春秋两季（11月至次年3月）</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-clock text-blue-500 mt-1 mr-2"></i>
                  <span>行程天数：4天3晚</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-credit-card text-blue-500 mt-1 mr-2"></i>
                  <span>预算参考：每人约1500-2500元</span>
                </li>
                <li className="flex items-start">
                  <i className="fa-solid fa-location-dot text-blue-500 mt-1 mr-2"></i>
                  <span>主要城市：湛江市区、雷州半岛</span>
                </li>
              </ul>
            </div>
          </div>
        </motion.section>
      </main>

      {/* Footer */}
      <footer className={`py-8 ${theme === 'dark' ? 'bg-slate-800 text-white/80' : 'bg-slate-100 text-slate-600'}`}>
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p>湛江4天3晚旅行计划 | 祝您旅途愉快！</p>
          <div className="flex justify-center space-x-4 mt-4">
            <a href="#" className="hover:text-blue-500 transition-colors">
              <i className="fa-solid fa-share-alt"></i> 分享
            </a>
            <a href="#" className="hover:text-blue-500 transition-colors">
              <i className="fa-solid fa-print"></i> 打印
            </a>
            <a href="#" className="hover:text-blue-500 transition-colors">
              <i className="fa-solid fa-download"></i> 下载
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}